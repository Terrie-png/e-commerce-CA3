import React, {Component} from "react"



export default class Index extends Component
{
    constructor(props)
    {
        super(props)

    }



    render()
    {
        return (
            <div className="form-container">
                    Logged in
            </div>
        )
    }
}